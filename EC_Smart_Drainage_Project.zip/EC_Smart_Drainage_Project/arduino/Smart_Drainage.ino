/*
  EC Project: AI-Based Smart Drainage Blockage Detection
  Board: Arduino Nano (ATmega328P)

  Wiring:
  HC-SR04: TRIG D11, ECHO D12, VCC 5V, GND GND
  ZJ-S201: signal yellow D2, red suitable supply, black GND
  Traffic-light module: R D8, Y D9, G D10, module GND GND
  2-pin buzzer: D7 and GND (if suitable for direct Arduino drive)

  Serial CSV columns:
  distance_cm,flow_lpm,pulses_per_second,status_code

  status_code: 0=normal, 1=warning, 2=possible blockage
*/

const byte TRIG_PIN = 11;
const byte ECHO_PIN = 12;
const byte FLOW_PIN = 2;
const byte RED_PIN = 8;
const byte YELLOW_PIN = 9;
const byte GREEN_PIN = 10;
const byte BUZZER_PIN = 7;

// ZJ-S201 typical starting calibration: frequency (Hz) = 7.5 * flow (L/min).
// If your measured flow is inaccurate, calibrate this constant using a measured volume.
const float PULSES_PER_LPM_PER_SECOND = 7.5;

// Tune after observing your actual pipe and sensor readings.
const float WARNING_DISTANCE_CM = 10.0;  // water closer than this = elevated water
const float CRITICAL_DISTANCE_CM = 5.0;  // water closer than this = very high water
const float LOW_FLOW_LPM = 0.5;

volatile unsigned long flowPulses = 0;
unsigned long lastSampleMs = 0;
unsigned long lastPrintMs = 0;
float smoothedDistance = -1.0;

void countFlowPulse() {
  flowPulses++;
}

float readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(3);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);
  if (duration == 0) return -1.0;
  return duration * 0.0343 / 2.0;
}

void setLights(byte status) {
  digitalWrite(RED_PIN, status == 2 ? HIGH : LOW);
  digitalWrite(YELLOW_PIN, status == 1 ? HIGH : LOW);
  digitalWrite(GREEN_PIN, status == 0 ? HIGH : LOW);

  if (status == 2) {
    tone(BUZZER_PIN, 2000);
  } else {
    noTone(BUZZER_PIN);
    digitalWrite(BUZZER_PIN, LOW);
  }
}

void setup() {
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(FLOW_PIN, INPUT_PULLUP);
  pinMode(RED_PIN, OUTPUT);
  pinMode(YELLOW_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(TRIG_PIN, LOW);
  digitalWrite(RED_PIN, LOW);
  digitalWrite(YELLOW_PIN, LOW);
  digitalWrite(GREEN_PIN, LOW);
  noTone(BUZZER_PIN);

  attachInterrupt(digitalPinToInterrupt(FLOW_PIN), countFlowPulse, FALLING);
  Serial.begin(9600);
  delay(500);
  Serial.println("distance_cm,flow_lpm,pulses_per_second,status_code");
  lastSampleMs = millis();
  lastPrintMs = millis();
}

void loop() {
  unsigned long now = millis();

  // Sample flow pulses once per second.
  if (now - lastSampleMs >= 1000UL) {
    unsigned long elapsed = now - lastSampleMs;
    lastSampleMs = now;

    noInterrupts();
    unsigned long pulses = flowPulses;
    flowPulses = 0;
    interrupts();

    float pulsesPerSecond = (pulses * 1000.0) / elapsed;
    float flowLpm = pulsesPerSecond / PULSES_PER_LPM_PER_SECOND;

    float distance = readDistanceCm();
    if (distance > 0 && distance < 400) {
      if (smoothedDistance < 0) smoothedDistance = distance;
      else smoothedDistance = 0.65 * smoothedDistance + 0.35 * distance;
    }

    // status: 0 normal, 1 warning, 2 possible blockage.
    // Both water level and flow are used in the decision.
    byte status = 0;
    if (smoothedDistance > 0) {
      bool waterElevated = smoothedDistance <= WARNING_DISTANCE_CM;
      bool waterVeryHigh = smoothedDistance <= CRITICAL_DISTANCE_CM;
      bool flowLow = flowLpm < LOW_FLOW_LPM;

      if (waterVeryHigh && flowLow) {
        status = 2;
      } else if (waterElevated && flowLow) {
        status = 1;
      } else if (waterVeryHigh) {
        status = 1;
      }
    }

    setLights(status);

    Serial.print(smoothedDistance, 2);
    Serial.print(",");
    Serial.print(flowLpm, 2);
    Serial.print(",");
    Serial.print(pulsesPerSecond, 2);
    Serial.print(",");
    Serial.println(status);
  }
}
