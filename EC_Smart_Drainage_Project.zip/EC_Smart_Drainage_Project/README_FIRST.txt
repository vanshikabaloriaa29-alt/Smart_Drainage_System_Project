
EC SMART DRAINAGE PROJECT - START HERE
======================================

Project folder
--------------
Keep the entire EC_Smart_Drainage_Project folder together. Do not move individual
Python files out of it. The Arduino sketch is in arduino/Smart_Drainage.ino.

PIN CONNECTIONS (Arduino Nano)
------------------------------
HC-SR04:
  VCC -> 5V
  GND -> GND
  TRIG -> D11
  ECHO -> D12

ZJ-S201 flow sensor:
  Yellow signal -> D2
  Black -> GND
  Red -> supply appropriate for the sensor (check its label/specification).
  The Nano, sensor and any external supply must share GND.
  Do NOT connect the 12V pump directly to an Arduino pin or 5V pin.

Traffic-light module:
  R -> D8
  Y -> D9
  G -> D10
  GND -> GND
  Confirm the module is suitable for 5V Arduino logic.

Buzzer:
  D7 and GND only if the buzzer is suitable for direct pin drive.
  The included sketch uses tone(). If the buzzer stays silent, leave it aside
  and test its type/current safely before reconnecting.

IMPORTANT SAFETY
----------------
Keep the pump disconnected while testing sensors and LEDs. Do not run water near
the computer. Never power the 12V pump directly from the Nano. Use a suitable
motor driver and a correctly rated supply, with a common ground where required.

STEP A - Arduino IDE
--------------------
1. Open arduino/Smart_Drainage.ino in Arduino IDE.
2. Select Tools > Board > Arduino AVR Boards > Arduino Nano.
3. Select the correct Tools > Port.
4. If upload fails on a Nano clone, try Tools > Processor > ATmega328P (Old Bootloader).
5. Upload once. The sketch stays on the Nano after USB is unplugged and plugged
   back in; you do not need to upload it every time.
6. Open Serial Monitor at 9600 baud to inspect the CSV readings.
   Close Serial Monitor before running a Python program because only one program
   can use the serial port at a time.

STEP B - VS CODE (Windows)
--------------------------
Open this whole project folder in VS Code.
Open Terminal > New Terminal and run:

  py -m venv .venv
  .venv\Scripts\activate
  py -m pip install -r requirements.txt

If "py" does not work, try "python" in those commands.

STEP C - Find your COM port
---------------------------
In Arduino IDE > Tools > Port, note the port such as COM5.
Use that port when a Python script asks for it.

STEP D - Test live readings
---------------------------
Close Serial Monitor, then run:

  python sensor_reader.py

Enter the COM port, e.g. COM5. Press Ctrl+C to stop.

STEP E - Collect labelled AI data
---------------------------------
Run:

  python collect_training_data.py

Collect separate sets while the physical system is in known conditions.
Use "normal" only when the flow is genuinely normal, "warning" for a real
warning-like condition, and "blockage" only for a safely simulated blockage.
Collect at least 30-50 samples per class, ideally more varied real samples.
Do not label pump-off / zero-flow readings as blockage unless the physical
condition truly represents blockage. This tool appends to data/training_data.csv.

STEP F - Train AI model
-----------------------
After collecting enough real data, run:

  python train_model.py

The model is saved to models/blockage_model.joblib. It is not meaningful if the
training data is too small, mislabeled, or contains only one condition.

STEP G - Dashboard
------------------
Run:

  python dashboard.py

Select the COM port. It displays live sensor readings and uses the trained model
if a model exists. Without a trained model, it shows the Arduino's rule-based
status instead.

Calibration notes
-----------------
The flow calibration constant is a starting value. Measure a known volume over a
known time to calibrate it. The distance thresholds (10 cm and 5 cm) depend on
where the HC-SR04 is mounted above the water. Adjust them after observing your
actual setup. The system identifies possible blockage patterns; it is not proof
of a real-world blockage without careful calibration and testing.
