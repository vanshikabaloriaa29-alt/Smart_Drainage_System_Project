import serial
import time

def main():
    port = input("Enter Arduino COM port (example COM5): ").strip()
    if not port:
        print("No COM port entered.")
        return

    try:
        with serial.Serial(port, 9600, timeout=2) as ser:
            time.sleep(2)  # Nano may reset when serial connects
            print("Reading live sensor data. Press Ctrl+C to stop.\n")
            while True:
                line = ser.readline().decode("utf-8", errors="ignore").strip()
                if not line or line.startswith("distance_cm"):
                    continue
                parts = line.split(",")
                if len(parts) != 4:
                    print("Arduino:", line)
                    continue
                try:
                    distance, flow, pulses, status = parts
                    print(
                        f"Distance: {float(distance):5.2f} cm | "
                        f"Flow: {float(flow):5.2f} L/min | "
                        f"Pulses/sec: {float(pulses):5.2f} | "
                        f"Arduino status: {status}"
                    )
                except ValueError:
                    print("Arduino:", line)
    except serial.SerialException as exc:
        print(f"Could not open {port}: {exc}")
        print("Close Arduino Serial Monitor and check the COM port.")
    except KeyboardInterrupt:
        print("\nStopped.")

if __name__ == "__main__":
    main()
