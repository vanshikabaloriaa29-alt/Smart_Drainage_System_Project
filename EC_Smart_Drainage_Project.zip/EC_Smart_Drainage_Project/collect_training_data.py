import csv
import os
import time
import serial
from datetime import datetime

DATA_DIR = "data"
CSV_PATH = os.path.join(DATA_DIR, "training_data.csv")
FIELDS = ["timestamp", "distance_cm", "flow_lpm", "pulses_per_second", "arduino_status", "label"]

def main():
    print("\nSMART DRAINAGE - TRAINING DATA COLLECTION")
    print("Labels: normal, warning, blockage")
    print("Only label a sample according to the real physical condition.")
    port = input("Arduino COM port (example COM5): ").strip()
    label = input("Label for this collection (normal/warning/blockage): ").strip().lower()
    if label not in {"normal", "warning", "blockage"}:
        print("Invalid label. Use normal, warning, or blockage.")
        return

    try:
        count = int(input("How many samples to collect? (suggest 30-50): ").strip())
        if count < 1:
            raise ValueError
    except ValueError:
        print("Enter a positive whole number.")
        return

    os.makedirs(DATA_DIR, exist_ok=True)
    write_header = not os.path.exists(CSV_PATH) or os.path.getsize(CSV_PATH) == 0

    try:
        with serial.Serial(port, 9600, timeout=2) as ser, open(CSV_PATH, "a", newline="", encoding="utf-8") as f:
            time.sleep(2)
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            if write_header:
                writer.writeheader()
            saved = 0
            print("Collecting. Press Ctrl+C to stop early.")
            while saved < count:
                line = ser.readline().decode("utf-8", errors="ignore").strip()
                parts = line.split(",")
                if len(parts) != 4:
                    continue
                try:
                    distance, flow, pulses, status = parts
                    distance = float(distance)
                    flow = float(flow)
                    pulses = float(pulses)
                    status = int(status)
                except ValueError:
                    continue
                if distance <= 0:
                    continue
                writer.writerow({
                    "timestamp": datetime.now().isoformat(timespec="seconds"),
                    "distance_cm": distance,
                    "flow_lpm": flow,
                    "pulses_per_second": pulses,
                    "arduino_status": status,
                    "label": label,
                })
                f.flush()
                saved += 1
                print(f"{saved}/{count}: distance={distance:.2f} cm, flow={flow:.2f} L/min, label={label}")
            print(f"\nSaved {saved} samples to {CSV_PATH}")
    except serial.SerialException as exc:
        print(f"Could not open serial port: {exc}")
        print("Close Arduino Serial Monitor and check the COM port.")
    except KeyboardInterrupt:
        print("\nStopped collection.")

if __name__ == "__main__":
    main()
