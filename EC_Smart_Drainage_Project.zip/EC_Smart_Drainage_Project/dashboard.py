import os
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox
import serial
import joblib
import pandas as pd
from datetime import datetime

MODEL_PATH = os.path.join("models", "blockage_model.joblib")
LOG_PATH = os.path.join("data", "live_readings.csv")
FEATURES = ["distance_cm", "flow_lpm", "pulses_per_second"]

class Dashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Smart Drainage Monitoring")
        self.root.geometry("640x430")
        self.root.minsize(580, 390)
        self.stop_event = threading.Event()
        self.ser = None
        self.model_bundle = None

        if os.path.exists(MODEL_PATH):
            try:
                self.model_bundle = joblib.load(MODEL_PATH)
            except Exception:
                self.model_bundle = None

        title = ttk.Label(root, text="AI-BASED SMART DRAINAGE BLOCKAGE DETECTION",
                          font=("Arial", 14, "bold"))
        title.pack(pady=(14, 8))

        controls = ttk.Frame(root)
        controls.pack(pady=4)
        ttk.Label(controls, text="Arduino COM port:").grid(row=0, column=0, padx=5)
        self.port_var = tk.StringVar(value="COM5")
        ttk.Entry(controls, textvariable=self.port_var, width=12).grid(row=0, column=1, padx=5)
        self.connect_btn = ttk.Button(controls, text="Connect", command=self.connect)
        self.connect_btn.grid(row=0, column=2, padx=5)
        self.disconnect_btn = ttk.Button(controls, text="Disconnect", command=self.disconnect, state="disabled")
        self.disconnect_btn.grid(row=0, column=3, padx=5)

        self.distance_var = tk.StringVar(value="-- cm")
        self.flow_var = tk.StringVar(value="-- L/min")
        self.pulse_var = tk.StringVar(value="-- pulses/sec")
        self.status_var = tk.StringVar(value="Waiting for Arduino")
        self.mode_var = tk.StringVar(
            value="AI model loaded" if self.model_bundle else "Rule-based status (train AI model after collecting data)"
        )

        panel = ttk.Frame(root, padding=12)
        panel.pack(fill="x", padx=18, pady=8)
        self._metric(panel, "Water distance", self.distance_var, 0)
        self._metric(panel, "Water flow", self.flow_var, 1)
        self._metric(panel, "Flow pulses", self.pulse_var, 2)

        ttk.Label(root, textvariable=self.status_var, font=("Arial", 17, "bold")).pack(pady=14)
        ttk.Label(root, textvariable=self.mode_var, wraplength=560, justify="center").pack(pady=4)
        ttk.Label(root, text="Note: sensor thresholds and flow calibration must be verified on your setup.",
                  wraplength=560).pack(pady=8)

        root.protocol("WM_DELETE_WINDOW", self.close)

    def _metric(self, parent, label, var, column):
        box = ttk.LabelFrame(parent, text=label, padding=12)
        box.grid(row=0, column=column, padx=5, sticky="nsew")
        ttk.Label(box, textvariable=var, font=("Arial", 14)).pack()
        parent.columnconfigure(column, weight=1)

    def connect(self):
        port = self.port_var.get().strip()
        try:
            self.ser = serial.Serial(port, 9600, timeout=1)
            time.sleep(2)
        except Exception as exc:
            self.ser = None
            messagebox.showerror("Connection error", f"Could not open {port}.\nClose Arduino Serial Monitor and check the port.\n\n{exc}")
            return
        self.stop_event.clear()
        self.connect_btn.configure(state="disabled")
        self.disconnect_btn.configure(state="normal")
        threading.Thread(target=self.read_loop, daemon=True).start()
        self.status_var.set("Connected. Waiting for readings...")

    def read_loop(self):
        while not self.stop_event.is_set() and self.ser:
            try:
                line = self.ser.readline().decode("utf-8", errors="ignore").strip()
                parts = line.split(",")
                if len(parts) != 4:
                    continue
                distance, flow, pulses, status = float(parts[0]), float(parts[1]), float(parts[2]), int(parts[3])
                if distance <= 0:
                    continue
                self.root.after(0, self.update_display, distance, flow, pulses, status)
                os.makedirs("data", exist_ok=True)
                new_file = not os.path.exists(LOG_PATH) or os.path.getsize(LOG_PATH) == 0
                with open(LOG_PATH, "a", encoding="utf-8") as f:
                    if new_file:
                        f.write("timestamp,distance_cm,flow_lpm,pulses_per_second,arduino_status,prediction\n")
                    prediction = self.predict(distance, flow, pulses)
                    f.write(f"{datetime.now().isoformat(timespec='seconds')},{distance},{flow},{pulses},{status},{prediction}\n")
            except (ValueError, serial.SerialException):
                continue
            except Exception:
                continue

    def predict(self, distance, flow, pulses):
        if not self.model_bundle:
            return None
        model = self.model_bundle["model"]
        row = pd.DataFrame([[distance, flow, pulses]], columns=self.model_bundle.get("features", FEATURES))
        return str(model.predict(row)[0])

    def update_display(self, distance, flow, pulses, arduino_status):
        self.distance_var.set(f"{distance:.2f} cm")
        self.flow_var.set(f"{flow:.2f} L/min")
        self.pulse_var.set(f"{pulses:.2f} pulses/sec")

        prediction = None
        if self.model_bundle:
            try:
                prediction = self.predict(distance, flow, pulses)
            except Exception:
                prediction = None

        if prediction:
            label = prediction.replace("_", " ").title()
            self.status_var.set(f"AI prediction: {label}")
        else:
            labels = {0: "NORMAL", 1: "WARNING", 2: "POSSIBLE BLOCKAGE"}
            self.status_var.set(f"Sensor status: {labels.get(arduino_status, 'CHECK SENSOR')}")

    def disconnect(self):
        self.stop_event.set()
        if self.ser:
            try:
                self.ser.close()
            except Exception:
                pass
        self.ser = None
        self.connect_btn.configure(state="normal")
        self.disconnect_btn.configure(state="disabled")
        self.status_var.set("Disconnected")

    def close(self):
        self.disconnect()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = Dashboard(root)
    root.mainloop()
