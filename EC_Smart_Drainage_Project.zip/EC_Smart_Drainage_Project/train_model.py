import os
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

DATA_PATH = os.path.join("data", "training_data.csv")
MODEL_DIR = "models"
MODEL_PATH = os.path.join(MODEL_DIR, "blockage_model.joblib")
FEATURES = ["distance_cm", "flow_lpm", "pulses_per_second"]

def main():
    if not os.path.exists(DATA_PATH):
        print("No training file yet. Run collect_training_data.py first.")
        return

    df = pd.read_csv(DATA_PATH)
    required = FEATURES + ["label"]
    if not all(col in df.columns for col in required):
        print("Training CSV is missing required columns.")
        return

    df = df.dropna(subset=required)
    df = df[df["label"].isin(["normal", "warning", "blockage"])]
    print("Samples per label:")
    print(df["label"].value_counts().to_string())

    if df["label"].nunique() < 2 or len(df) < 20:
        print("\nCollect more correctly labelled real samples from at least two classes.")
        return

    X = df[FEATURES].astype(float)
    y = df["label"].astype(str)
    # Stratify only when every class has at least two samples.
    stratify = y if y.value_counts().min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=stratify
    )

    model = make_pipeline(
        StandardScaler(),
        RandomForestClassifier(n_estimators=150, random_state=42, class_weight="balanced")
    )
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    print(f"\nHold-out accuracy: {accuracy_score(y_test, predictions):.2%}")
    print("\nClassification report:")
    print(classification_report(y_test, predictions, zero_division=0))

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump({"model": model, "features": FEATURES}, MODEL_PATH)
    print(f"Saved model to {MODEL_PATH}")

if __name__ == "__main__":
    main()
